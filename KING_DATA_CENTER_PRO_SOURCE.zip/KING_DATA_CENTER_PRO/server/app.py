from flask import Flask, request, jsonify, send_from_directory, render_template, abort
from pathlib import Path
from werkzeug.utils import secure_filename
import secrets, time, socket, threading

ROOT = Path(__file__).resolve().parent
STORAGE = ROOT / "storage"
STORAGE.mkdir(exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024
TOKEN = secrets.token_urlsafe(8)
LOCK = threading.Lock()
LATEST_FRAME = None
LATEST_FRAME_TIME = 0
COMMANDS = []
DEVICE = {"online": False, "last_seen": 0, "battery": None, "ram_available_mb": None,
          "ram_total_mb": None, "cpu_percent": None, "battery_temp_c": None,
          "thermal_status": None, "device": "Infinix"}

def authorized():
    supplied = request.headers.get("X-KING-TOKEN") or request.args.get("token", "")
    return secrets.compare_digest(str(supplied), TOKEN)

def require_auth():
    if not authorized():
        abort(401, "Неверный токен")

@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["Cache-Control"] = "no-store"
    return resp

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/status")
def status():
    require_auth()
    with LOCK:
        d = dict(DEVICE)
        frame_age = round(time.time() - LATEST_FRAME_TIME, 1) if LATEST_FRAME_TIME else None
    d["frame_age_seconds"] = frame_age
    d["files"] = len([p for p in STORAGE.iterdir() if p.is_file()])
    return jsonify(d)

@app.post("/api/heartbeat")
def heartbeat():
    require_auth()
    payload = request.get_json(silent=True) or {}
    with LOCK:
        DEVICE["online"] = True
        DEVICE["last_seen"] = time.time()
        for field in ("battery", "ram_available_mb", "ram_total_mb", "cpu_percent",
                      "battery_temp_c", "thermal_status"):
            DEVICE[field] = payload.get(field)
        DEVICE["device"] = payload.get("device", "Infinix")
    return jsonify(ok=True)

@app.post("/api/frame")
def frame():
    global LATEST_FRAME, LATEST_FRAME_TIME
    require_auth()
    data = request.get_data()
    if not data or len(data) > 2_500_000:
        abort(400, "Кадр пустой или слишком большой")
    with LOCK:
        LATEST_FRAME = data
        LATEST_FRAME_TIME = time.time()
    return jsonify(ok=True)

@app.get("/api/frame/latest")
def latest_frame():
    require_auth()
    with LOCK:
        data = LATEST_FRAME
        stamp = LATEST_FRAME_TIME
    if data is None:
        return ("Кадров пока нет", 404)
    from flask import Response
    return Response(data, mimetype="image/jpeg", headers={"X-Frame-Time": str(stamp)})

@app.post("/api/command")
def add_command():
    require_auth()
    payload = request.get_json(silent=True) or {}
    try:
        x, y = float(payload["x"]), float(payload["y"])
    except Exception:
        abort(400, "Нужны координаты x и y")
    if not (0 <= x <= 1 and 0 <= y <= 1):
        abort(400, "Координаты должны быть от 0 до 1")
    with LOCK:
        COMMANDS.append({"type": "tap", "x": x, "y": y, "created": time.time()})
        del COMMANDS[:-20]
    return jsonify(ok=True)

@app.get("/api/command/next")
def next_command():
    require_auth()
    with LOCK:
        cmd = COMMANDS.pop(0) if COMMANDS else None
    return jsonify(command=cmd)

@app.post("/api/upload")
def upload():
    require_auth()
    f = request.files.get("file")
    if not f:
        abort(400, "Файл не выбран")
    name = secure_filename(f.filename or "upload.bin")
    if not name:
        abort(400, "Недопустимое имя файла")
    target = STORAGE / name
    if target.exists():
        target = STORAGE / f"{int(time.time())}_{name}"
    f.save(target)
    return jsonify(ok=True, name=target.name)

@app.get("/api/files")
def list_files():
    require_auth()
    return jsonify(files=[{"name": p.name, "size": p.stat().st_size}
                          for p in sorted(STORAGE.iterdir()) if p.is_file()])

@app.get("/api/download/<path:name>")
def download(name):
    require_auth()
    safe = secure_filename(name)
    if not safe or safe != name:
        abort(400)
    return send_from_directory(STORAGE, safe, as_attachment=True)

def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()

if __name__ == "__main__":
    ip = local_ip()
    print("\n=== KING DATA CENTER PRO ===")
    print(f"На M31 открой: http://{ip}:8080")
    print(f"Адрес для приложения на этом Infinix: http://127.0.0.1:8080")
    print(f"ТОКЕН: {TOKEN}")
    print("Только локальная доверенная Wi-Fi сеть. Ctrl+C — остановка.\n")
    app.run(host="0.0.0.0", port=8080, threaded=True)
