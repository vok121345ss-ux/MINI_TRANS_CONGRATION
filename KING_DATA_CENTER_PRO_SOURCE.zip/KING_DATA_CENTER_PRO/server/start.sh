#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
pkg install python -y
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
