package com.king.remote;

import android.app.*;
import android.content.*;
import android.media.*;
import android.media.projection.*;
import android.hardware.display.DisplayManager;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import org.json.JSONObject;

public class CaptureService extends Service {
    MediaProjection projection; VirtualDisplay display; ImageReader reader;
    Handler handler; String server, token; Thread worker; volatile boolean running=false;
    int w=720,h=1280,density; long lastFramePost=0;
    @Override public void onCreate(){super.onCreate();handler=new Handler(Looper.getMainLooper());}
    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i==null)return START_NOT_STICKY;
        server=i.getStringExtra("server"); token=i.getStringExtra("token");
        int result=i.getIntExtra("result",0); Intent data=i.getParcelableExtra("data");
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("king","KING Remote",NotificationManager.IMPORTANCE_LOW));
        Notification n=new Notification.Builder(this,Build.VERSION.SDK_INT>=26?"king":"")
            .setContentTitle("KING: трансляция экрана активна").setContentText("Останови её в приложении KING Remote")
            .setSmallIcon(android.R.drawable.presence_video_online).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7,n);
        }
        if(data!=null){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);projection=m.getMediaProjection(result,data);startCapture();}
        return START_NOT_STICKY;
    }
    void startCapture(){
        DisplayMetrics dm=getResources().getDisplayMetrics(); density=dm.densityDpi;
        int sw=dm.widthPixels, sh=dm.heightPixels; float scale=Math.min(1f,720f/Math.max(sw,sh));
        w=Math.max(1,(int)(sw*scale)); h=Math.max(1,(int)(sh*scale));
        reader=ImageReader.newInstance(w,h, android.graphics.PixelFormat.RGBA_8888,2);
        display=projection.createVirtualDisplay("KING-screen",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        running=true;
        reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireLatestImage();if(im==null)return;
            long now=System.currentTimeMillis();if(now-lastFramePost<650)return;lastFramePost=now;
            Image.Plane p=im.getPlanes()[0];ByteBuffer buf=p.getBuffer();int px=p.getPixelStride(), row=p.getRowStride();
            Bitmap padded=Bitmap.createBitmap(row/px,h,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(buf);
            Bitmap bmp=Bitmap.createBitmap(padded,0,0,w,h);padded.recycle();
            ByteArrayOutputStream out=new ByteArrayOutputStream();bmp.compress(Bitmap.CompressFormat.JPEG,55,out);bmp.recycle();
            byte[] jpeg = out.toByteArray();
            new Thread(() -> postFrame(jpeg)).start();
        }catch(Exception ignored){}finally{if(im!=null)im.close();}},handler);
        worker=new Thread(()->{while(running){try{heartbeat();pollCommands();Thread.sleep(500);}catch(Exception e){try{Thread.sleep(1500);}catch(Exception ignored){}}}});
        worker.start();
    }
    void postFrame(byte[] bytes){try{HttpURLConnection c=(HttpURLConnection)new URL(server+"/api/frame").openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setRequestProperty("X-KING-TOKEN",token);c.setRequestProperty("Content-Type","image/jpeg");c.getOutputStream().write(bytes);c.getInputStream().close();c.disconnect();}catch(Exception ignored){}}
    int lastTotal=-1, lastIdle=-1;
    int cpuPercent(){
        try {
            java.io.BufferedReader br=new java.io.BufferedReader(new java.io.FileReader("/proc/stat"));
            String line=br.readLine();br.close();String[] a=line.trim().split("\\s+");
            int idle=Integer.parseInt(a[4]);int total=0;for(int i=1;i<a.length;i++)total+=Integer.parseInt(a[i]);
            int result=(lastTotal<0)?0:(int)(100f*(total-lastTotal-Math.max(0,idle-lastIdle))/Math.max(1,total-lastTotal));
            lastTotal=total;lastIdle=idle;return Math.max(0,Math.min(100,result));
        } catch(Exception e){return -1;}
    }
    void heartbeat()throws Exception{
        android.os.BatteryManager bm=(android.os.BatteryManager)getSystemService(BATTERY_SERVICE);
        int battery=bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);
        android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
        ((android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        Intent bi=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        double temp=bi==null?-1:bi.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE,-1)/10.0;
        int thermal=-1;
        if(Build.VERSION.SDK_INT>=29) thermal=((android.os.PowerManager)getSystemService(POWER_SERVICE)).getCurrentThermalStatus();
        JSONObject data=new JSONObject().put("device","Infinix").put("battery",battery)
            .put("ram_available_mb",mi.availMem/1048576).put("ram_total_mb",mi.totalMem/1048576)
            .put("cpu_percent",cpuPercent()).put("battery_temp_c",temp).put("thermal_status",thermal);
        HttpURLConnection c=(HttpURLConnection)new URL(server+"/api/heartbeat").openConnection();
        c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("X-KING-TOKEN",token);
        c.setRequestProperty("Content-Type","application/json");c.getOutputStream().write(data.toString().getBytes("UTF-8"));
        c.getInputStream().close();c.disconnect();
    }
    void pollCommands(){try{HttpURLConnection c=(HttpURLConnection)new URL(server+"/api/command/next").openConnection();c.setRequestProperty("X-KING-TOKEN",token);c.setConnectTimeout(1500);InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[1024];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();JSONObject obj=new JSONObject(new String(out.toByteArray(),"UTF-8"));c.disconnect();JSONObject cmd=obj.optJSONObject("command");if(cmd!=null&&"tap".equals(cmd.optString("type")))KingAccessibilityService.tap((float)cmd.optDouble("x"),(float)cmd.optDouble("y"));}catch(Exception ignored){}}
    @Override public void onDestroy(){running=false;if(worker!=null)worker.interrupt();if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}