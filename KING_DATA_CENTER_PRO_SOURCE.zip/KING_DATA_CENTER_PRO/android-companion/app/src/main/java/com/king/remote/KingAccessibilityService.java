package com.king.remote;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.Display;
import android.view.WindowManager;

public class KingAccessibilityService extends AccessibilityService {
    private static volatile KingAccessibilityService instance;
    @Override protected void onServiceConnected(){super.onServiceConnected();instance=this;}
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
    public static void tap(float nx,float ny){
        KingAccessibilityService s=instance;if(s==null)return;
        android.util.DisplayMetrics dm=new android.util.DisplayMetrics();
        ((WindowManager)s.getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        float x=Math.max(0,Math.min(dm.widthPixels-1,nx*dm.widthPixels));
        float y=Math.max(0,Math.min(dm.heightPixels-1,ny*dm.heightPixels));
        Path path=new Path();path.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,80);
        s.dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),null,null);
    }
}